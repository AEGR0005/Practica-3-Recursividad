public class Fibonacci {
}

public static double factorialIterativo(int n) {
    double producto = 1;

    for (int i = 2; i <= n; i++) {
        producto *= i;
    }

    return producto;
}

public static double factorialAcumulador(int n, double acumulador) {
    if (n <= 1)
        return acumulador;

    return factorialAcumulador(n - 1, n * acumulador);
}

void main() {
}


