public class MutacionesCodigo {
}

public static double potencia (long x, int n)
{
    if (n == 0)
        return 1;
    if (n % 2 == 0)
    {
        double mitad = potencia (x, n / 2);
        return mitad * mitad;
    } else {
        return x * potencia (x, n - 1);
    }
}

public static String invertir(String s) {
    if (s.length() <= 1) {
        return s;
    }

    char primero = s.charAt(0);
    char ultimo = s.charAt(s.length() - 1);

    String medio = s.substring(1, s.length() - 1);


    return ultimo + invertir(medio) + primero;
}
public static int contarUnosIterativo(int[] a) {
    int count = 0;
    for (int i = 0; i < a.length; i++) {
        if (a[i] == 1) count++;
    }
    return count;
}

void main() {
}

